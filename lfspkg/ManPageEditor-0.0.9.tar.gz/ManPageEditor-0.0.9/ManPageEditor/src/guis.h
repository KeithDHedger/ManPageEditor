/*
 *
 * K.D.Hedger 2013 <kdhedger68713@gmail.com>
 *
*/

#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <sys/stat.h>

#include <gtksourceview/gtksourceview.h>
#include <gtksourceview/gtksourcebuffer.h>

#ifndef _GUIS_
#define _GUIS_

void buildMainGui(void);
void buildFindReplace(void);
void buildWordCheck(int documentCheck);

#endif